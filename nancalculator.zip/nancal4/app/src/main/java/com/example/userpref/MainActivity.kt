package com.example.userpref

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class MainActivity : ComponentActivity() {
    private var mediaPlayer: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        // Set the theme to the splash theme before super.onCreate
        setTheme(R.style.Theme_SplashScreen_Custom)

        super.onCreate(savedInstanceState)
        initializeBackgroundMusic()

        // Use a handler to delay showing the main content
        Handler(Looper.getMainLooper()).postDelayed({
            // After delay, switch to main theme and set content
            setTheme(R.style.Theme_ObjectComboGenerator)
            initializeContent()
        }, 2500) // 2.5 seconds display time
    }

    private fun initializeBackgroundMusic() {
        try {
            // Create a MediaPlayer instance with your music resource
            mediaPlayer = MediaPlayer.create(this, R.raw.your_background_music)
            mediaPlayer?.apply {
                isLooping = true
                setVolume(0.5f, 0.5f)
                start()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onResume() {
        super.onResume()
        if (mediaPlayer != null && !mediaPlayer!!.isPlaying) {
            mediaPlayer?.start()
        }
    }

    override fun onPause() {
        super.onPause()
        mediaPlayer?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer?.apply {
            if (isPlaying) stop()
            release()
        }
        mediaPlayer = null
    }

    private fun initializeContent() {
        setContent {
            MaterialTheme {
                FoodFastApp()
            }
        }
    }
}

@Composable
fun FoodFastApp() {
    val navController = rememberNavController()
    var showInstructions by remember { mutableStateOf(false) }

    // Define app colors based on the images
    val backgroundColor = Color(0xFFFED7C3) // Exact peach background from images
    val buttonColor = Color(0xFFFF6347) // Tomato orange for buttons
    val textColor = Color.Black
    val whiteButtonColor = Color.White

    NavHost(
        navController = navController,
        startDestination = "startScreen"
    ) {
        composable("startScreen") {
            StartScreen(
                onStartClick = { navController.navigate("menuScreen") },
                onInstructionsClick = { showInstructions = true },
                backgroundColor = backgroundColor,
                buttonColor = buttonColor
            )

            // Instructions popup
            if (showInstructions) {
                InstructionsPopup(
                    onDismiss = { showInstructions = false },
                    backgroundColor = Color.White,
                    buttonColor = buttonColor
                )
            }
        }

        composable("menuScreen") {
            MenuScreen(
                onFitIndexClick = { navController.navigate("fitIndexScreen") },
                onMealMeterClick = { navController.navigate("mealMeterScreen") },
                backgroundColor = backgroundColor,
                buttonColor = whiteButtonColor,
                textColor = textColor
            )
        }

        composable("fitIndexScreen") {
            FitIndexScreen(
                onCalculateClick = { /* Calculate logic */ },
                backgroundColor = backgroundColor,
                buttonColor = buttonColor,
                textColor = textColor
            )
        }

        composable("mealMeterScreen") {
            MealMeterScreen(
                onCalculateClick = { /* Calculate logic */ },
                backgroundColor = backgroundColor,
                buttonColor = buttonColor,
                textColor = textColor
            )
        }
    }
}

@Composable
fun StartScreen(
    onStartClick: () -> Unit,
    onInstructionsClick: () -> Unit,
    backgroundColor: Color,
    buttonColor: Color
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor)
    ) {
        // Full screen background image with the Foodfast image
        Image(
            painter = painterResource(id = R.drawable.foodfast_background),
            contentDescription = "Foodfast Background",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.FillBounds
        )

        // Invisible clickable area over the START button in the image
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .offset(y = (-100).dp) // Adjusted upward from -30.dp to -60.dp
                .size(width = 170.dp, height = 80.dp) // Slightly wider and taller
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null, // No visual feedback
                    onClick = onStartClick
                )
        )

        // Invisible clickable area over the Instructions button in the image
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .offset(y = (-130).dp) // Adjusted upward from -100.dp to -130.dp
                .size(width = 180.dp, height = 80.dp) // Slightly wider and taller
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null, // No visual feedback
                    onClick = onInstructionsClick
                )
        )

        // Play button in the bottom right corner (already in your image)
        // We'll keep this clickable too
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 16.dp, end = 16.dp)
                .size(40.dp)
                .clickable { /* Play/Pause music */ }
        )
    }
}

@Composable
fun InstructionsPopup(
    onDismiss: () -> Unit,
    backgroundColor: Color,
    buttonColor: Color
) {
    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .width(300.dp)
                .wrapContentHeight()
                .clip(RoundedCornerShape(16.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(backgroundColor)
                    .padding(24.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Instructions",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        modifier = Modifier
                            .size(24.dp)
                            .clickable { onDismiss() }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "1. Choose between Fit Index or Meal Meter\n\n" +
                            "2. For Fit Index, enter your details to calculate your fitness level\n\n" +
                            "3. For Meal Meter, select a food and enter grams to calculate calories",
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }
    }
}

@Composable
fun MenuScreen(
    onFitIndexClick: () -> Unit,
    onMealMeterClick: () -> Unit,
    backgroundColor: Color,
    buttonColor: Color,
    textColor: Color
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        ) {
            Surface(
                onClick = onFitIndexClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .padding(horizontal = 32.dp),
                color = buttonColor,
                shape = RoundedCornerShape(30.dp)
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.fillMaxSize()
                ) {
                    Text(
                        text = "Fit Index",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = textColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Surface(
                onClick = onMealMeterClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .padding(horizontal = 32.dp),
                color = buttonColor,
                shape = RoundedCornerShape(30.dp)
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.fillMaxSize()
                ) {
                    Text(
                        text = "Meal Meter",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = textColor
                    )
                }
            }
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FitIndexScreen(
    onCalculateClick: () -> Unit,
    backgroundColor: Color,
    buttonColor: Color,
    // textColor was missing in the parameter list but used in the function
    textColor: Color = Color.Black // Added with default value
) {
    var height by remember { mutableStateOf("") }
    var weight by remember { mutableStateOf("") }
    var age by remember { mutableStateOf("") }
    var activityLevel by remember { mutableStateOf("Sedentary") }
    val activityLevels = listOf("Sedentary", "Light", "Moderate", "Active", "Very Active")
    var expanded by remember { mutableStateOf(false) }

    // State for results
    var showResults by remember { mutableStateOf(false) }
    var bmiResult by remember { mutableStateOf(0.0) }
    var bmrResult by remember { mutableStateOf(0.0) }
    var tdeeResult by remember { mutableStateOf(0.0) }

    // State for validation errors
    var heightError by remember { mutableStateOf(false) }
    var weightError by remember { mutableStateOf(false) }
    var ageError by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Title - centered, exact size
            Text(
                text = "Fit Index",
                fontSize = 40.sp,
                fontWeight = FontWeight.Bold,
                color = textColor,
                modifier = Modifier.padding(vertical = 16.dp),
                textAlign = TextAlign.Center
            )

            // User Detail subtitle - left aligned
            Text(
                text = "User Detail",
                fontSize = 28.sp,
                color = textColor,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                textAlign = TextAlign.Start
            )

            // Single White Card containing all inputs
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    // Fixed Height Input
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Height",
                            tint = Color.Gray,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "Height (cm)",
                            fontSize = 16.sp,
                            modifier = Modifier
                                .weight(1f)
                                .padding(start = 8.dp),
                            color = if (heightError) Color.Red else textColor
                        )
                        OutlinedTextField(
                            value = height,
                            onValueChange = {
                                height = it
                                heightError = false
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = textColor,
                                unfocusedTextColor = textColor,
                                focusedBorderColor = buttonColor,
                                unfocusedBorderColor = Color.LightGray,
                                errorBorderColor = Color.Red
                            ),
                            isError = heightError,
                            modifier = Modifier
                                .width(150.dp)
                                .height(50.dp)
                        )
                    }

                    // Fixed Weight Input
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Weight",
                            tint = Color.Gray,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "Weight (kg)",
                            fontSize = 16.sp,
                            modifier = Modifier
                                .weight(1f)
                                .padding(start = 8.dp),
                            color = if (weightError) Color.Red else textColor
                        )
                        OutlinedTextField(
                            value = weight,
                            onValueChange = {
                                weight = it
                                weightError = false
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = textColor,
                                unfocusedTextColor = textColor,
                                focusedBorderColor = buttonColor,
                                unfocusedBorderColor = Color.LightGray,
                                errorBorderColor = Color.Red
                            ),
                            isError = weightError,
                            modifier = Modifier
                                .width(150.dp)
                                .height(50.dp)
                        )
                    }

                    // Fixed Age Input
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Age",
                            tint = Color.Gray,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "Age",
                            fontSize = 16.sp,
                            modifier = Modifier
                                .weight(1f)
                                .padding(start = 8.dp),
                            color = if (ageError) Color.Red else textColor
                        )
                        OutlinedTextField(
                            value = age,
                            onValueChange = {
                                age = it
                                ageError = false
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = textColor,
                                unfocusedTextColor = textColor,
                                focusedBorderColor = buttonColor,
                                unfocusedBorderColor = Color.LightGray,
                                errorBorderColor = Color.Red
                            ),
                            isError = ageError,
                            modifier = Modifier
                                .width(150.dp)
                                .height(50.dp)
                        )
                    }

                    // Activity Level Dropdown
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Activity Level",
                            tint = Color.Gray,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "Activity Level",
                            fontSize = 16.sp,
                            modifier = Modifier
                                .weight(1f)
                                .padding(start = 8.dp),
                            color = textColor
                        )
                        Box {
                            Surface(
                                modifier = Modifier.width(150.dp),
                                color = Color.White,
                                shape = RoundedCornerShape(4.dp),
                                border = BorderStroke(1.dp, Color.LightGray)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .clickable { expanded = true }
                                        .padding(horizontal = 12.dp)
                                        .height(50.dp), // Increased from 40dp to match other inputs
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = activityLevel,
                                        fontSize = 16.sp,
                                        modifier = Modifier.weight(1f),
                                        color = textColor // Explicitly set text color
                                    )
                                    Icon(
                                        imageVector = Icons.Default.ArrowDropDown,
                                        contentDescription = "Dropdown",
                                        tint = Color.Gray
                                    )
                                }
                            }

                            DropdownMenu(
                                expanded = expanded,
                                onDismissRequest = { expanded = false },
                                modifier = Modifier.width(150.dp)
                            ) {
                                activityLevels.forEach { level ->
                                    DropdownMenuItem(
                                        text = { Text(text = level, color = textColor) },
                                        onClick = {
                                            activityLevel = level
                                            expanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Calculate Button
            Button(
                onClick = {
                    // Validate inputs
                    val heightValid = height.isNotBlank() && height.toDoubleOrNull() != null && height.toDouble() > 0
                    val weightValid = weight.isNotBlank() && weight.toDoubleOrNull() != null && weight.toDouble() > 0
                    val ageValid = age.isNotBlank() && age.toIntOrNull() != null && age.toInt() > 0

                    // Set error flags
                    heightError = !heightValid
                    weightError = !weightValid
                    ageError = !ageValid

                    // Calculate if all inputs are valid
                    if (heightValid && weightValid && ageValid) {
                        val heightInM = height.toDouble() / 100 // Convert cm to meters
                        val weightKg = weight.toDouble()
                        val ageYears = age.toInt()

                        // Calculate BMI
                        bmiResult = weightKg / (heightInM * heightInM)

                        // Calculate BMR (Basal Metabolic Rate) using Mifflin-St Jeor Equation
                        // This is a simplified version for demonstration - in a real app you'd want more sophisticated calculations
                        bmrResult = 10 * weightKg + 6.25 * height.toDouble() - 5 * ageYears + 5 // For males

                        // Calculate TDEE (Total Daily Energy Expenditure)
                        val activityMultiplier = when(activityLevel) {
                            "Sedentary" -> 1.2
                            "Light" -> 1.375
                            "Moderate" -> 1.55
                            "Active" -> 1.725
                            "Very Active" -> 1.9
                            else -> 1.2
                        }
                        tdeeResult = bmrResult * activityMultiplier

                        showResults = true
                    }

                    onCalculateClick()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = buttonColor),
                shape = RoundedCornerShape(28.dp)
            ) {
                Text(
                    text = "Calculate",
                    fontSize = 18.sp,
                    color = Color.Black
                )
            }

            // Results section (appears after calculation)
            if (showResults) {
                Spacer(modifier = Modifier.height(24.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Text(
                            text = "Results",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = textColor,
                            modifier = Modifier.padding(bottom = 16.dp)
                        )

                        // BMI Result
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "BMI:", fontWeight = FontWeight.Bold, color = textColor)
                            Text(
                                text = String.format("%.1f", bmiResult),
                                color = textColor
                            )
                        }

                        // BMI Category
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Category:", fontWeight = FontWeight.Bold, color = textColor)
                            Text(
                                text = when {
                                    bmiResult < 18.5 -> "Underweight"
                                    bmiResult < 25 -> "Normal weight"
                                    bmiResult < 30 -> "Overweight"
                                    else -> "Obese"
                                },
                                color = textColor
                            )
                        }

                        // BMR Result
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "BMR:", fontWeight = FontWeight.Bold, color = textColor)
                            Text(
                                text = String.format("%.0f calories/day", bmrResult),
                                color = textColor
                            )
                        }

                        // TDEE Result
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "TDEE:", fontWeight = FontWeight.Bold, color = textColor)
                            Text(
                                text = String.format("%.0f calories/day", tdeeResult),
                                color = textColor
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Dietary recommendations
                        Text(
                            text = "Dietary Recommendations:",
                            fontWeight = FontWeight.Bold,
                            color = textColor,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )

                        Text(
                            text = when {
                                bmiResult < 18.5 -> "• Increase calorie intake\n• Focus on protein and healthy fats\n• Consider weight training"
                                bmiResult < 25 -> "• Maintain current calorie intake\n• Balanced diet with variety\n• Regular exercise"
                                bmiResult < 30 -> "• Moderate calorie deficit\n• Increase protein intake\n• Regular cardio and strength training"
                                else -> "• Supervised calorie deficit\n• Low glycemic index foods\n• Regular physical activity"
                            },
                            color = textColor
                        )
                    }
                }
            }
        }
    }
}


@Composable
fun MealMeterScreen(
    onCalculateClick: () -> Unit,
    backgroundColor: Color,
    buttonColor: Color,
    textColor: Color
) {
    var selectedFood by remember { mutableStateOf("select food") }
    var grams by remember { mutableStateOf("") }
    var expandedFood by remember { mutableStateOf(false) }

    // Food options with calorie content per 100g
    val foodOptions = mapOf(
        "Pizza" to 266,
        "Burger" to 295,
        "Salad" to 33,
        "Rice" to 130,
        "Chicken" to 165,
        "Pasta" to 158,
        "Bread" to 265,
        "Eggs" to 155,
        "Banana" to 89,
        "Apple" to 52,
        "Fish" to 206,
        "Beef" to 250
    )

    // State for results
    var showResults by remember { mutableStateOf(false) }
    var calories by remember { mutableStateOf(0) }
    var protein by remember { mutableStateOf(0.0) }
    var carbs by remember { mutableStateOf(0.0) }
    var fat by remember { mutableStateOf(0.0) }

    // State for validation errors
    var foodError by remember { mutableStateOf(false) }
    var gramsError by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Title
            Text(
                text = "Meal Meter",
                fontSize = 40.sp,
                fontWeight = FontWeight.Bold,
                color = textColor,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            // Food Calories subtitle
            Text(
                text = "Food Calories",
                fontSize = 28.sp,
                color = textColor,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            // Food Selection
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                color = Color.White,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, if (foodError) Color.Red else Color.Transparent)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            expandedFood = true
                            foodError = false
                        }
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = selectedFood,
                            fontSize = 16.sp,
                            color = if (selectedFood == "select food") Color.Gray else Color.Black
                        )

                        Icon(
                            imageVector = Icons.Default.KeyboardArrowRight,
                            contentDescription = "Select",
                            tint = Color.Gray
                        )
                    }
                }

                DropdownMenu(
                    expanded = expandedFood,
                    onDismissRequest = { expandedFood = false },
                    modifier = Modifier.fillMaxWidth(0.8f)
                ) {
                    foodOptions.keys.toList().sorted().forEach { food ->
                        DropdownMenuItem(
                            text = { Text(text = "$food (${foodOptions[food]} cal/100g)") },
                            onClick = {
                                selectedFood = food
                                expandedFood = false
                                foodError = false
                            }
                        )
                    }
                }
            }

            // Grams input
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                color = Color.White,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, if (gramsError) Color.Red else Color.Transparent)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextField(
                        value = grams,
                        onValueChange = {
                            grams = it
                            gramsError = false
                        },
                        placeholder = { Text("Grams") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White,
                            disabledContainerColor = Color.White,
                            unfocusedPlaceholderColor = Color.Gray,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        )
                    )

                    Icon(
                        imageVector = Icons.Default.KeyboardArrowRight,
                        contentDescription = "Input",
                        tint = Color.Gray
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Calculate Button
            Surface(
                onClick = {
                    // Validate inputs
                    val foodValid = selectedFood != "select food"
                    val gramsValid = grams.isNotBlank() && grams.toDoubleOrNull() != null && grams.toDouble() > 0

                    // Set error flags
                    foodError = !foodValid
                    gramsError = !gramsValid

                    // Calculate if all inputs are valid
                    if (foodValid && gramsValid) {
                        val gramsValue = grams.toDouble()
                        val caloriesPer100g = foodOptions[selectedFood] ?: 0

                        // Calculate calories
                        calories = (caloriesPer100g * gramsValue / 100).toInt()

                        // Calculate approximate macronutrients based on food type
                        // This is a simplified estimation for demonstration
                        when (selectedFood) {
                            "Rice", "Pasta", "Bread", "Banana", "Apple" -> {
                                // High carb foods
                                carbs = calories * 0.8 / 4  // 80% of calories from carbs
                                protein = calories * 0.1 / 4 // 10% from protein
                                fat = calories * 0.1 / 9    // 10% from fat
                            }
                            "Chicken", "Fish", "Eggs", "Beef" -> {
                                // High protein foods
                                carbs = calories * 0.05 / 4  // 5% of calories from carbs
                                protein = calories * 0.7 / 4  // 70% from protein
                                fat = calories * 0.25 / 9    // 25% from fat
                            }
                            "Pizza", "Burger" -> {
                                // High fat foods
                                carbs = calories * 0.4 / 4   // 40% of calories from carbs
                                protein = calories * 0.2 / 4 // 20% from protein
                                fat = calories * 0.4 / 9     // 40% from fat
                            }
                            "Salad" -> {
                                // Low calorie, mixed macros
                                carbs = calories * 0.6 / 4   // 60% of calories from carbs
                                protein = calories * 0.2 / 4 // 20% from protein
                                fat = calories * 0.2 / 9     // 20% from fat
                            }
                            else -> {
                                // Default balanced macros
                                carbs = calories * 0.5 / 4   // 50% of calories from carbs
                                protein = calories * 0.25 / 4 // 25% from protein
                                fat = calories * 0.25 / 9    // 25% from fat
                            }
                        }

                        showResults = true
                    }

                    onCalculateClick()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                color = buttonColor,
                shape = RoundedCornerShape(28.dp)
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.fillMaxSize()
                ) {
                    Text(
                        text = "Calculate fusion",
                        fontSize = 18.sp,
                        color = Color.White
                    )
                }
            }

            // Results section (appears after calculation)
            if (showResults) {
                Spacer(modifier = Modifier.height(24.dp))

                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color.White,
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Text(
                            text = "Nutritional Information",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = textColor,
                            modifier = Modifier.padding(bottom = 16.dp)
                        )

                        // Food and portion
                        Text(
                            text = "$selectedFood (${grams}g)",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = textColor,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        Divider(
                            color = Color.LightGray,
                            thickness = 1.dp,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )

                        // Calories
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Calories:", fontWeight = FontWeight.Bold, color = textColor)
                            Text(
                                text = "$calories kcal",
                                color = textColor
                            )
                        }

                        // Protein
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Protein:", fontWeight = FontWeight.Bold, color = textColor)
                            Text(
                                text = String.format("%.1f g", protein),
                                color = textColor
                            )
                        }

                        // Carbs
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Carbohydrates:", fontWeight = FontWeight.Bold, color = textColor)
                            Text(
                                text = String.format("%.1f g", carbs),
                                color = textColor
                            )
                        }

                        // Fat
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Fat:", fontWeight = FontWeight.Bold, color = textColor)
                            Text(
                                text = String.format("%.1f g", fat),
                                color = textColor
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Daily value context
                        Text(
                            text = "% of Daily Value*",
                            fontSize = 14.sp,
                            fontStyle = FontStyle.Italic,
                            color = textColor
                        )

                        // Daily value percentages
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Calories:", color = textColor)
                            Text(
                                text = String.format("%.1f%%", calories / 2000.0 * 100),
                                color = textColor
                            )
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Protein:", color = textColor)
                            Text(
                                text = String.format("%.1f%%", protein / 50.0 * 100),
                                color = textColor
                            )
                        }

                        Text(
                            text = "*Based on a 2,000 calorie diet",
                            fontSize = 12.sp,
                            fontStyle = FontStyle.Italic,
                            color = Color.Gray,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }
            }
        }
    }
}

// For testing/debugging only - use this to see where clickable areas are
@Composable
fun StartScreenWithDebugOutlines(
    onStartClick: () -> Unit,
    onInstructionsClick: () -> Unit,
    backgroundColor: Color,
    buttonColor: Color
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor)
    ) {
        // Full screen background image
        Image(
            painter = painterResource(id = R.drawable.foodfast_background),
            contentDescription = "Foodfast Start Screen",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.FillBounds
        )

        // Debug outline for START button area
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .offset(y = (-60).dp) // Adjusted upward from -30.dp to -60.dp
                .size(width = 150.dp, height = 70.dp) // Slightly wider and taller
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null, // No visual feedback
                    onClick = onStartClick
                )
        )

        // Debug outline for Instructions button area
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .offset(y = (-100).dp)
                .size(width = 140.dp, height = 40.dp)
                .border(2.dp, Color.Blue)  // Blue outline to see button area
                .clickable(onClick = onInstructionsClick)
        )
    }
}